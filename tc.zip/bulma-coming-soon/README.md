# Bulma Coming Soon

A Pen created on CodePen.io. Original URL: [https://codepen.io/emkelley/pen/gKPaYa](https://codepen.io/emkelley/pen/gKPaYa).

Coming soon page built with the Bulma CSS framework. Released as part of my set of free Bulma templates. 