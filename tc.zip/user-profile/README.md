# User Profile 

A Pen created on CodePen.io. Original URL: [https://codepen.io/ajduke/pen/GMxJGq](https://codepen.io/ajduke/pen/GMxJGq).

Click on name of person in above, to see transition effect

P.S.
This Pen is inspired by following UI Movement article -

https://uimovement.com/ui/4272/user-profile/
