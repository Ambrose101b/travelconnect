$('.name-label').click(()=>{
	$('.details-wrapper').toggleClass('open')
	$('.background-image-wrapper').toggleClass('open')
})