# Don't let the door hit you on the way out.

A Pen created on CodePen.io. Original URL: [https://codepen.io/coopergoeke/pen/KKzrgOQ](https://codepen.io/coopergoeke/pen/KKzrgOQ).

Just a fun idea I had for a logout button where the icon animates and the figure falls off the screen. This pen features some heavy use of CSS variables and transitions on SVG elements. Animating all the figure's limbs is tedious work but it pays off when you see the finished product.